Java.asJSONCompatible({
    animation: function (maid, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale, modelMap) {
        sittingRotationSkirt = modelMap.get("sittingRotationSkirt");
        reverseSittingHiddenSkirt = modelMap.get("_sittingHiddenSkirt");
        reverseSitHiddenSkirt = modelMap.get("_sitHiddenSkirt");
        if (sittingRotationSkirt != undefined) {
            if (maid.isRidingMarisaBroom() || maid.isRiding()) {
                sittingRotationSkirt.setHidden(true);
				sittingRotationSkirt.setRotateAngleX(-1.483);
				reverseSittingHiddenSkirt.setHidden(false);
				reverseSitHiddenSkirt.setHidden(false);
            } else if (maid.isSitting()) {
                sittingRotationSkirt.setHidden(false);
				sittingRotationSkirt.setRotateAngleX(-1.483);
				reverseSittingHiddenSkirt.setHidden(true);
				reverseSitHiddenSkirt.setHidden(false);
            } else {
                sittingRotationSkirt.setHidden(false);
				sittingRotationSkirt.setRotateAngleX(0);
				reverseSittingHiddenSkirt.setHidden(true);
				reverseSitHiddenSkirt.setHidden(true);
            }
        }
    }
})